<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use App\Models\Vehicle;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class FileRecordExport implements FromCollection, WithMapping ,WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    protected $id;

    public function __construct($id)
    {
        $this->id = $id;
    }

    public function collection()
    {
        
        return Vehicle::where("file_id",$this->id)
        ->where("add_by",Auth::user()->id)
        ->cursor();
    }

    public function map($fileRecord): array
    {

        return [
            $fileRecord->registration_numbers,
            $fileRecord->chasisnum,
            $fileRecord->enginenum,
            $fileRecord->allocation,
            $fileRecord->agreementid,
            $fileRecord->username,
            $fileRecord->emi_amt,
            $fileRecord->pos,
            $fileRecord->tbr,
            $fileRecord->bkts,
            $fileRecord->bank,
            $fileRecord->productname,
            $fileRecord->model,
            $fileRecord->address,
            $fileRecord->file_id,
        ];
    }

    public function headings(): array
    {
        // Exported Excel Headers, in order, which you should match them base on
        // manipulated data in above
        return [
            'registration_numbers',
            'chasisnum',
            'enginenum',
            'allocation',
            'agreementid',
            'username',
            'emi_amt',
            'pos',
            'tbr',
            'bkts',
            'bank',
            'productname',
            'model',
            'address',
            'file_id',
        ];
    }
}
